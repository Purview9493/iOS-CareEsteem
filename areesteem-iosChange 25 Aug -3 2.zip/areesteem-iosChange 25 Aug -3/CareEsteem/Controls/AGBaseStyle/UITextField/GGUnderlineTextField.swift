//
//  UnderlineTextField.swift
//  Alfayda
//
//  Created by Wholly-iOS on 22/08/18.
//  Copyright © 2018 Whollysoftware. All rights reserved.
//


class GGUnderlineTextField:UnderLineTextField{
    // Provides left padding for image
   
}
