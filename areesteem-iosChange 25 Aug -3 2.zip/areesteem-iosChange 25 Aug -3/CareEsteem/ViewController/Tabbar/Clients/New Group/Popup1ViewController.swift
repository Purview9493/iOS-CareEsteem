//
//  Popup1ViewController.swift
//  CareEsteem
//
//  Created by Amit Saini on 16/08/25.
//

import UIKit

class Popup1ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.9)

        // Do any additional setup after loading the view.
    }
    

    @IBAction func tapYesButton(_ sender: Any) {
    }
    @IBAction func tapNoButton(_ sender: Any) {
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
